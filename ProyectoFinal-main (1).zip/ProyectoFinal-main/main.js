// Para que el usuario calcule el precio de venta sin descuento en efectivo

// function CalcularPrecioCredito(precioCredito) {
//   return precioCredito * 3.5;
// }

// let precioCredito = CalcularPrecioCredito(precioCredito);
// precioCredito = precioCredito.toFixed(2);

// alert("El precio del producto con tarjeta de credito es: " + precioCredito);

// const product = {
//   nombre: "Adulto Mediano",
//   precio: 299,
// };

function selectProduct(producto) {
  localStorage.setItem("producto", JSON.stringify(producto));
  location.href = "http://127.0.0.1:5500/vistas/carrito.html";
}

function onLoad() {
  const producto = localStorage.getItem("producto");
  const productoJSON = JSON.parse(producto);
  console.log(productoJSON);
}
